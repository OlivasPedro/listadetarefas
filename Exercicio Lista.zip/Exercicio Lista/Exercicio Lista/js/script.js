document.addEventListener('DOMContentLoaded', () => {
    let tasks = [];
    let table = document.querySelector('#taskTable');
    let form = document.querySelector('#taskForm');
    let importanceList = document.querySelector('#importanceList');
    let clearCompletedButton = document.querySelector('#clearCompleted');

    let descricao = document.querySelector('#descricao');
    let autor = document.querySelector('#autor');
    let departamento = document.querySelector('#departamento');
    let importancia = document.querySelector('#importancia');
    let paga = document.querySelector('#paga');
    let valor = document.querySelector('#valor');
    let realizada = document.querySelector('#realizada');
    let duracao = document.querySelector('#duracao');
    let sortImportanceButton = document.querySelector('#sortImportance');

    sortImportanceButton.addEventListener('click', () => {
        updateImportanceList();
    });


    paga.addEventListener('change', function() {
        valor.disabled = !this.checked;
    });

    realizada.addEventListener('change', function() {
        duracao.disabled = !this.checked;
    });

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        let task = {
            descricao: descricao.value,
            autor: autor.value,
            departamento: departamento.value,
            importancia: parseInt(importancia.value),
            paga: paga.checked,
            valor: paga.checked ? parseFloat(valor.value) : null,
            realizada: realizada.checked,
            duracao: realizada.checked ? parseFloat(duracao.value) : null
        };

        tasks.push(task);
        updateTable();
        //updateImportanceList();
        clearForm();
    });

    clearCompletedButton.addEventListener('click', () => {
        tasks.forEach((task, index) => {
            if (task.realizada) {
                tasks.splice(index, 1);
                index--;
            }
        });
        updateTable();
        updateImportanceList();
    });

    function updateTable() {
        const tbody = table.querySelector('tbody');
        tbody.innerHTML = '';

        tasks.forEach((task, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${task.descricao}</td>
                <td>${task.autor}</td>
                <td>${task.departamento}</td>
                <td>${task.importancia}</td>
                <td>${task.paga ? 'Sim' : 'Não'}</td>
                <td>${task.valor !== null ? task.valor.toFixed(2) : 'N/A'}</td>
                <td>${task.realizada ? 'Sim' : 'Não'}</td>
                <td>${task.duracao !== null ? task.duracao + 'h' : 'N/A'}</td>
                <td><button class="delete" data-index="${index}">Excluir</button></td>
            `;
            tbody.appendChild(row);
        });
    }

    function updateImportanceList() {
        importanceList.innerHTML = '';

        const sortedTasks = [...tasks].sort((a, b) => a.importancia - b.importancia);
        sortedTasks.forEach(task => {
            const li = document.createElement('li');
            li.textContent = task.descricao;
            importanceList.appendChild(li);
        });
    }

    function deleteTask(index) {
        tasks.splice(index, 1);
        updateTable();
        updateImportanceList();
    }

    function clearForm() {
        descricao.value = '';
        autor.value = '';
        departamento.value = '';
        importancia.value = '';
        paga.checked = false;
        valor.value = '';
        realizada.checked = false;
        duracao.value = '';
        valor.disabled = true;
        duracao.disabled = true;
    }

    table.addEventListener('click', event => {
        if (event.target.matches('button.delete')) {
            const index = parseInt(event.target.getAttribute('data-index'));
            deleteTask(index);
        }
    });
});
